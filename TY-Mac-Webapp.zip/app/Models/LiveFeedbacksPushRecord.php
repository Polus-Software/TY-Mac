<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LiveFeedbacksPushRecord extends Model
{
    use HasFactory;

    protected $table = 'live_feedbacks_push_record';
}

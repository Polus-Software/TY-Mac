<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SingleSessionChat extends Model
{
    use HasFactory;

    protected $table = 'single_session_chat_log';

}

<?php $__env->startComponent('mail::message'); ?>

<h1>Hello, <?php echo e($details['firstname']); ?> <?php echo e($details['lastname']); ?></h1>
<p>Welcome to ThinkLit!  Let's get started</p>

<p>We are excited to have you learn new skills in a personalized way!</p>

<p>At ThinkLit, we make learning fun, interactive, & simple.</p>

<p>Get started by exploring our courses </p>

<p>If you have any questions, please email us at support@thinklit.com</p>

Regards,<br>
Thinklit Team

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


<?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Emails/confirmationMail.blade.php ENDPATH**/ ?>
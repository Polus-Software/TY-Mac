
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('Layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- container -->
<input type="hidden" id="course_id" value="<?php echo e($course_id); ?>" />
<div class="container-fluid llp-container">
  <div class="row">
  <div class="left_sidebar">
      <!-- include sidebar here -->
      <?php echo $__env->make('Course.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-8 right_card_block">
      <!-- main -->
      <main>
        <?php echo csrf_field(); ?>
        <section class="row g-3 llp-view">
        <div class="py-4"><h3 class="titles">Course Overview</h3></div>
          <div class="col-12">
            <label>Course Title</label>
            <p><?php echo e($course_details['title']); ?></p>
          </div>
          <div class="col-12">
            <label>Course Description</label>
            <p><?php echo e($course_details['description']); ?></p>
          </div>
          <div class="col-md-6">
            <label>Category</label>
            <p><?php echo e($course_details['category']); ?></p>
          </div>
          <div class="col-md-6">
            <label>Level</label>
            <p><?php echo e($course_details['difficulty']); ?></p>
          </div>
          <div class="col-md-6">
            <label>Instructor name</label>
            <p><?php echo e($course_details['instructor']); ?></p>
          </div>
          <div class="col-md-6">
            <label>Class Duration in hours</label>
            <p><?php echo e($course_details['duration']); ?> h</p>
          </div>
          <div class="col-12">
            <label>What you'll learn</label>
            <ul>
            <?php $__currentLoopData = $course_details['whatlearn']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $whatlearn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($whatlearn); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
          <div class="col-12">
            <label>Who is this course is for?</label>
            <p>
            <?php $__currentLoopData = $course_details['whothis']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $whothis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($whothis != ''): ?>
            <?php echo e($whothis); ?>

            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
          </div>
          <div class="col-12">
            <label>Course image</label>
            <div style="margin-top:15px;">
                <img src="<?php echo e(asset('/storage/courseImages/'.$course_details['image'])); ?>" alt="" style="width:320px; height:240px;">
            </div>
          </div>
          <div class="col-12">
            <label>Course thumbnail image</label>
            <div style="margin-top:15px;">
                <img src="<?php echo e(asset('/storage/courseThumbnailImages/'.$course_details['thumbnail'])); ?>" alt="" style="width:500px; height:300px;">
            </div>
          </div>
          <div class="d-grid gap-2 d-md-flex justify-content-md-end mb-5">
            <a id="edit_course" style="" class="btn btn-primary" href="<?php echo e(route('edit-course', ['course_id' => $course_id])); ?>">Edit course</a>
          </div>
          </section>
      </main>
    </div>
	<div class="col-1"></div>
  </div>
</div>
<!-- container ends -->


<script>
  // if(document.getElementById('publish').innerHTML == "Unpublish") {
  //   document.getElementById('edit_course').style.display = "none";
  // } else {
  //   document.getElementById('edit_course').style.display = "block";
  // }
  
  // let coursePoint = 2;
  // let descPoint = 2;
  // document.getElementById('add-more-who-learn').addEventListener('click', (event) =>{

  // var input = document.createElement("INPUT");
  // input.setAttribute("name", "who_learn_points_" + coursePoint);
  // document.getElementById('who_learn_points_count').value = coursePoint;
  // coursePoint++;
  // document.getElementById("add-points").appendChild(input);
   
  // });

  // document.getElementById('add-more-what-learn').addEventListener('click', (event) =>{

  // var inputElement = document.createElement("INPUT");
  // inputElement.setAttribute("name", "what_learn_" + descPoint);
  // document.getElementById('what_learn_points_count').value = descPoint;
  // descPoint++;
  // document.getElementById("add-more-points").appendChild(inputElement);

   
  // });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Course/admin/view/view_course.blade.php ENDPATH**/ ?>
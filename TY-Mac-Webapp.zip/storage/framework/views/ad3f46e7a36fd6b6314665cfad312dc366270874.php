
<?php $__env->startSection('content'); ?>
<style>
  .btn-outline-success {
    border-color: #000000 !important;
}
.btn-outline-success:hover {
  background-color: #fff !important;
  border-color: #000000 !important;
  color: #000000 !important;
}

/* section .card-2{
    border: 1px solid #E0E0E0 !important;
    border-radius: 10px;
    background:#fff;
    outline: 1px solid #AF7E00;
    cursor: pointer;
}

section .card-2:hover, .card-2:active, .card-2.active-batch{
    border: 1px solid #E0E0E0 !important;
    border-radius: 10px;
    background:#FFF9E8;
    outline: 1px solid #AF7E00;
    cursor: pointer;
} */

  </style>
<header class="d-flex align-items-center mb-3">
    <div class="container">
        <div class="row mt-5">
            <div class="col-lg-12">
                <div class="think-horizontal-card mb-3 mt-5">
                    <div class="row g-0">
                        <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                            <img src="<?php echo e(asset('/storage/courseThumbnailImages/'.$courseDetails['course_thumbnail_image'])); ?>" class="img-fluid col-md-12 col-sm-12 col-12 card-image h-100" alt="coursepicture">
                        </div>
                        <div class="col-lg-8 col-md-12 col-sm-12 col-12">
                            <div class="card-body">
                                <h5 class="card-title pb-3 mb-0">
                                    <?php echo e($courseDetails['course_title']); ?>

                                </h5>
                                <p class="card-text think-text-color-grey position-relative"> 
                                <span class="think-truncated-text">
                                    <?php echo e(Str::limit($courseDetails['description'], 180, '...')); ?>

                                </span></p>
                                <div class="row">
                                    <div class="col-lg-5 col-md-12 col-sm-12 col-12 mb-3">
                                        <?php for($i=1;$i<=5;$i++): ?>
                                        <?php if($i <= $courseDetails['rating']): ?>
                                            <i class="fas fa-star rateCourse"></i>
                                        <?php else: ?>
                                            <i class="far fa-star rateCourse"></i>
                                        <?php endif; ?>
                                        <?php endfor; ?>
                                            <small class="ms-1">
                                            <?php if($courseDetails['use_custom_ratings'] == false): ?> 
                                                (<?php echo e($courseDetails['ratingsCount']); ?>) 
                                            <?php else: ?>
                                                (60)
                                            <?php endif; ?>
                                            <?php echo e($courseDetails['studentCount']); ?> participants</small>
                                        </div>
                                        <div class="col-lg think-text-color-grey">
                                            <p><img class="me-1" src="/storage/icons/category__icon.svg" alt="error">
                                                <span class="text-truncate"><?php echo e(Str::limit($courseDetails['course_category'], 15, '...')); ?></span>
                                            </p>
                                        </div>
                                        <div class="col-6 col-lg-3 col-md-3 col-sm-6 text-center text-truncate think-text-color-grey">
                                            <p class="fw-bold text-truncate"><i class="far fa-user pe-1"></i>
                                                <?php echo e($courseDetails['instructor_firstname']); ?> <?php echo e($courseDetails['instructor_lastname']); ?>

                                            </p>
                                        </div>
                                        <div class="col ps-0 text-end think-text-color-grey">
                                            <p class="fw-bold text-truncate"><img class="me-1" src="/storage/icons/level__icon.svg" alt="error">       
                                                <?php echo e($courseDetails['course_difficulty']); ?>

                                            </p>
                                        </div>
                                        <div class="col-lg-2 col-md-3 col-sm-3 col-6 think-text-color-grey">
                                            <p class="fw-bold"><i class="far fa-clock pe-1"></i><?php echo e($courseDetails['duration']); ?></p>
                                        </div>
                                       
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<section>
<div class="container mb-5">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="border-bottom pb-3">Choose a Cohort</h1>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-4 col-sm-12 col-12 mt-4">
            <div class="card-2 text-center" style="width: auto;">
               <input type="hidden" id="batch_id" value="<?php echo e($singleCourseDetail['batch_id']); ?>">
                    <div class="card-body">
                        <i class="far fa-calendar-alt pb-3"></i>
                        <p class="think-register-card-title think-tertiary-color"><?php echo e($singleCourseDetail['batchname']); ?></p>
                        <p class="card-text-1 mb-1">Cohort starts - <?php echo e($singleCourseDetail['start_date']); ?></p>
                        <p class="card-text-1 mb-1 fs-14"><?php echo e($singleCourseDetail['title']); ?></p>
                        <p class="card-text">
                            <?php echo e($singleCourseDetail['start_time']); ?> <?php echo e($singleCourseDetail['time_zone']); ?> - <?php echo e($singleCourseDetail['end_time']); ?>

                            <?php echo e($singleCourseDetail['time_zone']); ?>

                        </p>
                    
                    </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row mt-4 mb-4">
        <div class="buttons d-flex justify-content-end mt-2">
            <?php echo csrf_field(); ?>
            <button type="submit" id="registerNowButton" class="btn btn-secondary think-btn-secondary">Proceed</button>
            <input type="hidden" id="course_id" value="<?php echo e($courseDetails['course_id']); ?>">
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/assets/enrollcourse.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/assets/enrolledCoursePage.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('child-scripts'); ?>
<script>
document.getElementsByClassName('card-2')[0].classList.add('active-batch');
    document.getElementById('search-btn').addEventListener('click', function(e) {
  e.preventDefault();
  let searchTerm = document.getElementById('search-box').value;
  let path = "/course-search?search=" + searchTerm;
  window.location = '/course-search?search=' + searchTerm;
});

    let cards = document.getElementsByClassName('card-2');
    for(var index = 0; index < cards.length; index++) {
        cards[index].addEventListener('click', function (event){
            this.classList.add("active-batch");
            for(var index = 0; index < cards.length; index++) {
                if (cards[index]!=this) {
                    console.log(cards[index]);
                    cards[index].classList.remove("active-batch");
                }
            }
    });
}

document.getElementById('registerNowButton').addEventListener('click', (event) => {
    
     let courseId = document.getElementById('course_id').value;
     let activeBatch = document.getElementsByClassName('active-batch')[0].children[0];
     let batchId = activeBatch.value;
     window.location.replace('/enrolled-course/' + courseId + '?batchId=' + batchId);
});

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Instructor/cohortSelection.blade.php ENDPATH**/ ?>
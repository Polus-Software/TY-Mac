<?php $__env->startComponent('mail::message'); ?>

<h1>Hi <?php echo e($data['instructorName']); ?>,<h1>

You have got a new message from your student <?php echo e($data['studentName']); ?> on ThinkLit.

To view the message, please log in to your account on ThinkLit.com

Regards,<br>
The ThinkLit Team


<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Emails/MailAfterQuestion.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('Layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- container -->
<div class="container-fluid llp-container">
  <div class="row">
    <div class="left_sidebar">
      <!-- include sidebar here -->
      <?php echo $__env->make('Course.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-8 right_card_block">
      <!-- main -->
      <main>
        <?php if(Route::current()->getName() == 'edit-course'): ?>
        <input type="hidden" id="route_val" value="edit" />
        <form action="<?php echo e(route('update-course')); ?>" enctype="multipart/form-data" method="POST" class="row g-3 llp-form">
        <input type="hidden" id="course_id" name="course_id" value="<?php echo e($course_id); ?>">
        <input type="hidden" id="what_learn_points_count" name="what_learn_points_count" value="<?php echo e(count($whatLearn)); ?>">
        <input type="hidden" id="who_learn_points_count" name="who_learn_points_count">
        <?php else: ?>
        <input type="hidden" id="route_val" value="new" />
        <form action="<?php echo e(route('save-course')); ?>" enctype="multipart/form-data" method="POST" class="row g-3 llp-form">
        <input type="hidden" id="what_learn_points_count" name="what_learn_points_count" value="1">
        <input type="hidden" id="who_learn_points_count" name="who_learn_points_count">
        <?php endif; ?>
        <?php echo csrf_field(); ?>
          <div class="py-4"><h3 class="titles">Course Overview</h3>
        </div>
          <div class="col-12">
            <label for="title">Course Title</label>
            <?php if(isset($course_details['title'])): ?>
            <input type="text" class="form-control" id="title" name="course_title" value="<?php echo e($course_details['title']); ?>">
            <?php else: ?>
            <input type="text" class="form-control" id="title" name="course_title" placeholder="Ex: Fundamentals of Product Management" value="<?php echo e(old('course_title')); ?>">
            <?php endif; ?>
            <?php if($errors->has('course_title')): ?>
              <span class="text-danger"><?php echo e($errors->first('course_title')); ?></span>
            <?php endif; ?>
          </div>
          <div class="col-12">
            <label for="description">Course Description</label>
            <?php if(isset($course_details['description'])): ?>
            <textarea type="text" class="form-control autosize" id="description" name="description"><?php echo e($course_details['description']); ?></textarea>
            <?php else: ?>
            <textarea type="text" class="form-control autosize" id="description" name="description" placeholder="Product Management is the profession of building products. By taking this course, you will learn the fundamentals of Product Management"><?php echo e(old('description')); ?></textarea>
            <?php endif; ?>
            <?php if($errors->has('description')): ?>
              <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
            <?php endif; ?>
          </div>
          <div class="col-md-6">
            <label for="category">Category</label>
            <select type="text" class="form-select" id="course_category" name="course_category">
            <option value="">Select</option>
            <?php $__currentLoopData = $courseCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(isset($course_details['description']) && $courseCategory->id == $course_details['category_id']): ?>
            <option value="<?php echo e($courseCategory->id); ?>" selected><?php echo e($courseCategory->category_name); ?></option>
            <?php elseif(old('course_category') == $courseCategory->id): ?>
              <option value="<?php echo e($courseCategory->id); ?>" selected><?php echo e($courseCategory->category_name); ?></option>
            <?php else: ?>
            <option value="<?php echo e($courseCategory->id); ?>"><?php echo e($courseCategory->category_name); ?></option>
            <?php endif; ?>                            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
            </select>
            <?php if($errors->has('course_category')): ?>
              <span class="text-danger"><?php echo e($errors->first('course_category')); ?></span>
            <?php endif; ?>
          </div>
          <div class="col-md-6">
            <label for="level">Level</label>
            <select type="text" class="form-select" id="difficulty" name="difficulty">
              <?php if(isset($course_details['difficulty']) && $course_details['difficulty'] =='Beginner'): ?>
              <option value ="Beginner" selected>Beginner</option>
              <?php else: ?>
              <option value ="Beginner" <?php echo e(old('difficulty') == "Beginner" ? 'selected' : ''); ?>>Beginner</option>
              <?php endif; ?>
              <?php if(isset($course_details['difficulty']) && $course_details['difficulty'] =='Intermediate'): ?>
              <option value ="Intermediate" selected>Intermediate</option>
              <?php else: ?>
              <option value ="Intermediate" <?php echo e(old('difficulty') == "Intermediate" ? 'selected' : ''); ?>>Intermediate</option>
              <?php endif; ?>
              <?php if(isset($course_details['difficulty']) && $course_details['difficulty'] =='Advanced'): ?>
              <option value ="Advanced" selected>Advanced</option>
              <?php else: ?>
              <option value ="Advanced" <?php echo e(old('difficulty') == "Advanced" ? 'selected' : ''); ?>>Advanced</option>
              <?php endif; ?>
            </select>
            <?php if($errors->has('difficulty')): ?>
              <span class="text-danger"><?php echo e($errors->first('difficulty')); ?></span>
            <?php endif; ?>
          </div>
          <div class="col-md-6">
            <label for="instructor-name">Instructor name</label>
            <select class="form-select" id="instructor" name="instructor">
            <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($course_details['instructor_id']) && $instructor->id == $course_details['instructor_id']): ?>
            <option value ="<?php echo e($instructor->id); ?>" selected><?php echo e($instructor->firstname); ?> <?php echo e($instructor->lastname); ?></option>
            <?php else: ?>
            <option value ="<?php echo e($instructor->id); ?>" <?php echo e(old('instructor') == "$instructor->id" ? 'selected' : ''); ?>><?php echo e($instructor->firstname); ?> <?php echo e($instructor->lastname); ?></option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
            </select>
            <?php if($errors->has('instructor')): ?>
              <span class="text-danger"><?php echo e($errors->first('instructor')); ?></span>
            <?php endif; ?>
          </div>
          <div class="col-md-6">
            <label for="duration">Class Duration in hours</label>            
            <?php if(isset($course_details['duration'])): ?>
            <input type="number" class="form-control" id="duration" name="course_duration" value="<?php echo e($course_details['duration']); ?>">
            <?php else: ?>
            <input type="number" class="form-control" id="duration" name="course_duration" value="<?php echo e(old('course_duration') ? old('course_duration') : '1'); ?>">
            <?php endif; ?>
            <?php if($errors->has('course_duration')): ?>
              <span class="text-danger"><?php echo e($errors->first('course_duration')); ?></span>
            <?php endif; ?>
          </div>



          <div class="col-md-6">
            <label for="course-rating">Custom Rating</label>
            <?php if(isset($course_details['duration'])): ?>
            <select class="form-select" id="course_rating" name="course_rating" value="<?php echo e($course_details['course_rating']); ?>">
            <?php else: ?>
            <select class="form-select" id="course_rating" name="course_rating" value="">
            <?php endif; ?>
            <?php for($i = 1; $i <= 5; $i++): ?>
              <option value ="<?php echo e($i); ?>" selected><?php echo e($i); ?></option>
            <?php endfor; ?>         
            </select>
            <?php if($errors->has('course_rating')): ?>
              <span class="text-danger"><?php echo e($errors->first('course_rating')); ?></span>
            <?php endif; ?>
          </div>
          <div class="col-md-6" style="margin-top: 2.2rem;">
            <?php if(isset($course_details['use_custom_ratings'])): ?>
            <?php 
                $checked = $course_details['use_custom_ratings'] ? 'checked' : ''; 
            ?>
            <input type="checkbox" id="use_custom_ratings" name="use_custom_ratings" <?php echo e($checked); ?>>
            <label for="use_custom_ratings">Use custom ratings?</label> 
            <?php else: ?>
            <input type="checkbox" id="use_custom_ratings" name="use_custom_ratings">
            <label for="use_custom_ratings">Use custom ratings?</label> 
            <?php endif; ?>
          </div>


         
          <div class="col-12">
            <label for="what-learn">What you'll learn</label>            
            <?php if(isset($whatLearn)): ?>
            <?php ($whatCount = 0); ?>
            <?php $__currentLoopData = $whatLearn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $learn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($learn!=''): ?>
            <?php ($whatCount = $whatCount + 1); ?>
                <input type="text" class="form-control mt-2" id="what-learn" name="what_learn_<?php echo e($whatCount); ?>" value="<?php echo e($learn); ?>">
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <input type="text" class="form-control" id="what-learn" name="what_learn_1" value="<?php echo e(old('what_learn_1')); ?>">
            <?php endif; ?>
            <?php if($errors->has('what_learn_1')): ?>
              <span class="text-danger">This field is required</span>
            <?php endif; ?>
            <div id="add-more-points"></div>
            <button type="button" class="btn btn-secondary btn-sm mt-3" id="add-more-what-learn">Add section</button>
          </div>
          <div class="col-12">
            <label for="who-course">Who is this course is for?</label><br>
            
            <!-- <label for="who-course-description">Description</label>            
            <?php if(isset($course_details['short_description'])): ?>
            <textarea class="form-control mb-3" id="who_learn_description" name="who_learn_description" rows="4"><?php echo e($course_details['short_description']); ?></textarea>
            <?php else: ?>
            <textarea class="form-control mb-3" id="who_learn_description" name="who_learn_description" rows="4"></textarea>
            <?php endif; ?>

            <?php if($errors->has('who_learn_description')): ?>
              <span class="text-danger mb-3">This field is required</span><br>
            <?php endif; ?> -->
            
            <label for="who-course-points mt-2">Points</label>
            <?php if(isset($course_details['course_details_points'])): ?>
            <textarea class="form-control mb-3" name="who_learn_points" rows="4"><?php echo e($course_details['course_details_points']); ?></textarea>
            <?php else: ?>
            <textarea class="form-control mb-3" name="who_learn_points" rows="4"><?php echo e(old('who_learn_points')); ?></textarea>
            <?php endif; ?>
            <?php if($errors->has('who_learn_points')): ?>
              <span class="text-danger mb-3">This field is required</span><br>
            <?php endif; ?>
          </div>
          <div class="col-12">
            <label>Course image</label>
            <div class="row">
              <?php if(isset($course_details['image'])): ?>
              <div class="col-4"><img src="<?php echo e(asset('storage/courseImages/'.$course_details['image'])); ?>" class="img-thumbnail no-image-border" alt="..."></div>
              <?php else: ?>
              <div class="col-4"><img src="<?php echo e(asset('storage/images/placeholder.png')); ?>" class="img-thumbnail no-image-border" alt="..."></div>
              <div class="col">
                <p>Important guidelines: <b>600x285</b> pixels</p>
                <p>Image must be less than <b>500kb</b> </p>
                <p> supported file formats: jpg, jpeg, png, .svg.</p>
              </div>
              <?php endif; ?>
            <div class="input-group mt-3 mb-3">
             
              <input type="file" class="form-control mb-2" id="course-image" name="course_image">

              <label class="input-group-text mb-2 left_right_padding" for="course-image">Upload Image</label>
            </div>
            <?php if($errors->has('course_image')): ?>
              <span class="text-danger"><?php echo e($errors->first('course_image')); ?></span>
            <?php endif; ?>   
            </div>
          </div>
          <div class="col-12">
            <label>Course thumbnail image</label>
            <div class="row">
            <?php if(isset($course_details['thumbnail'])): ?>
            <img src="<?php echo e(asset('storage/courseThumbnailImages/'.$course_details['thumbnail'])); ?>" alt="" style="width:500; height:400px;">
            <?php else: ?>
              <div class="col-4"><img src="<?php echo e(asset('storage/images/placeholder.png')); ?>" class="img-thumbnail no-image-border" alt="..."></div>
              <div class="col">
                <p>Important guidelines: <b>395x186 pixels</b></p>
                <p>Image must be less than <b>100kb</b> </p>
                <p> supported file formats: jpg, jpeg, png, .svg.</p>
              </div>
              <?php endif; ?>
            <div class="input-group mt-3 mb-3">
              <input type="file" class="form-control mb-2" id="course-thumbnail-image" name="course_thumbnail_image">
              <label class="input-group-text mb-2 left_right_padding" for="course-thumbnail-image">Upload Image</label>
            </div>
            <?php if($errors->has('course_thumbnail_image')): ?>
              <span class="text-danger">This course thumbnail image field is required</span>
            <?php endif; ?> 
            </div>
          </div>
          <div class="d-grid gap-2 d-md-flex justify-content-md-end mb-5">          
          <?php if(Route::current()->getName() == 'edit-course'): ?>
          <a class="btn btn-outline-secondary" role="button" href="<?php echo e(route('view-course', ['course_id' => $course_id])); ?>">Cancel</a>
          <?php else: ?>
          <a class="btn btn-outline-secondary" role="button" href="<?php echo e(route('manage-courses')); ?>">Cancel</a>
          <?php endif; ?>
          <button class="btn btn-primary" id="save_course" type="submit" value="Save as draft & continue">Save as draft & continue</button>
          </div>
        </form>
      </main>
    </div>
	<div class="col-1"></div>
  </div>
</div>
<!-- container ends -->


<script>
  let coursePoint = 1;
  let descPoint = 1;
  if(document.getElementById('route_val').value == "edit") {
    let rating = document.getElementById('course_rating').getAttribute('value');
    document.getElementById('course_rating').value = rating;
  }
  if(document.getElementById('add-more-who-learn')){
    document.getElementById('add-more-who-learn').addEventListener('click', (event) =>{

    var input = document.createElement("INPUT");
    coursePoint++;
    input.setAttribute("name", "who_learn_points_" + coursePoint);
    document.getElementById('who_learn_points_count').value = coursePoint;
    document.getElementById("add-points").appendChild(input);
    
    });
  }
  if(document.getElementById('add-more-what-learn')){
  document.getElementById('add-more-what-learn').addEventListener('click', (event) =>{

  var inputElement = document.createElement("INPUT");
  descPoint++;
  inputElement.setAttribute("name", "what_learn_" + descPoint);
  document.getElementById('what_learn_points_count').value = descPoint;
  document.getElementById("add-more-points").appendChild(inputElement);

   
  });
  }


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Course/admin/create/create_course.blade.php ENDPATH**/ ?>
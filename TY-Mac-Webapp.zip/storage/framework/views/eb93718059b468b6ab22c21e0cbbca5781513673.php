
<?php $__env->startSection('content'); ?>
<style>
  .btn-outline-success {
    border-color: #000000 !important;
  }

  .btn-outline-success:hover {
    background-color: #fff !important;
    border-color: #000000 !important;
    color: #000000 !important;
  }

  .question-btn {
    border: 1px solid #FFFFFF;
    color: #FFFFFF;
    background: #2C3443;
    border-radius: 10px;
    width: 190px;
    height: 40px;
    font-size: 14x;
    font-weight: bold;
    font-family: 'Roboto', sans-serif;
  }
</style>

<header class="ty-mac-header-bg d-flex align-items-center mt-3">
  <div class="container">
    <div class="row mt-5">
      <div class="col-lg-6 col-md-12 order-2 order-lg-1 p-3 pt-4">

        <div class="text-content-wrapper w-100 text-lg-start">
          <p class="mb-2"><?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($singleCourseDetail['course_title']); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </p>
        </div>
        <div class="row row-1">
          <div class="col-auto">
            <p class="border-end pe-4"><i class="far fa-clock"></i><?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($singleCourseDetail['duration']); ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
          </div>
          <div class="col-auto">
            <p class="border-end pe-4"><img class="me-1" src="/storage/icons/level__icon.svg" alt="error"><?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($singleCourseDetail['course_difficulty']); ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
          </div>
          <div class="col-auto p-0">
            <p class="ms-2"><?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <img class="me-1 think-w-14_5" src="/storage/icons/category__icon.svg" alt="error"> <?php echo e($singleCourseDetail['course_category']); ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
          </div>
        </div>
        <div class="row row-2 mb-2">
          <div class="col-lg-12">
            <p class="para-1 mb-2">What You'll Learn</p>
            <?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $singleCourseDetail['short_description']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="para-2 mb-1"><img class="me-2" src="/storage/icons/tick__icon.svg" alt="error"><?php echo e($value); ?> <br>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>

          </div>
        </div>
        <div class="row row-3 pt-2">
          <div class="col-auto">
            <p class="">Instructed by <strong class="text-capitalize">
                <?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($singleCourseDetail['instructor_firstname']); ?> <?php echo e($singleCourseDetail['instructor_lastname']); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </strong></p>
          </div>
          <div class="col-auto">|</div>
          <div class="col-auto">
          <?php if(count($batchDetails)): ?>
            <p>Upcoming Cohort: <strong><?php echo e($batchDetails[0]['batch_start_date']); ?></strong></p>
          <?php endif; ?>
          </div>
        </div>

        <div class="row align-items-center mt-2">
          <?php if (! ($userType == 'admin' || $userType == 'instructor' || $userType == 'content-creator')): ?>
          <?php if($enrolledFlag == false && $cohort_full_status == false): ?>
          <div class="col-md-auto">
            <a class="btn think-btn-tertiary think-h-48" id="enrollButton">
              Enroll now
            </a>
            <input type="hidden" id="course_id" value="<?php echo e($singleCourseDetail['id']); ?>">
            <input type="hidden" id="user_id" value="<?php echo e(Auth::user() ? Auth::user()->id : ''); ?>">
          </div>
          <?php else: ?>
          <div class="col-md-auto">
            <?php if($enrolledFlag == true): ?>
              <h6 class="m-0 think-color-primary">Already enrolled!</h6>
            <?php else: ?>
              <h6 class="m-0 think-color-primary">Cohort is full!</h6>
            <?php endif; ?>
          </div>
          <?php endif; ?>
          <div class="col-md-auto"><a class="btn think-btn-tertiary-outline think-h-48" type="button" data-bs-toggle="modal" data-bs-target="#contactModal" data-bs-id="<?php echo e($singleCourseDetail['id']); ?>"><span>Have a question?</span></a></div>
          <?php endif; ?>
        </div>
        <div class="row mt-2">
          <?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-12">
            <span class="fw-bold">Share this course: </span>
              <a style="display:none;" class="btn" target="_blank" href="http://www.facebook.com/sharer.php?s=100&p[title]= <?php echo urlencode($singleCourseDetail['course_title']); ?>&amp;p[summary]=<?php echo urlencode($singleCourseDetail['description']) ?>&amp;p[url]=<?php echo urlencode(url('/')); ?>&amp;p[images][0]=<?php echo urlencode('/storage/courseImages/' . $singleCourseDetail['course_image']); ?>">
              <a style="margin-left: 1rem;" target="_blank" href="http://www.facebook.com/sharer.php?s=100&p[title]= <?php echo urlencode($singleCourseDetail['course_title']); ?>&amp;p[summary]=<?php echo urlencode($singleCourseDetail['description']) ?>&amp;p[url]=<?php echo urlencode(url($currenturl)); ?>&amp;p[images][0]=<?php echo urlencode('/storage/courseImages/' . $singleCourseDetail['course_image']); ?>">
              <i class="fab fa-facebook fa-lg btn-dark me-3"></i></a>
              <input type="hidden" id="twittertitle" value="<?php echo e($singleCourseDetail['course_title']); ?>">
              <input type="hidden" id="twitterdescription" value="<?php echo e($singleCourseDetail['description']); ?>">
              <input type="hidden" id="twittercreator" value="<?php echo e($singleCourseDetail['course_title']); ?>">
              <input type="hidden" id="twitterimage" value="<?php echo e(asset('/storage/courseImages/'.$singleCourseDetail['course_image'])); ?>">
            <a target="_blank" href="https://twitter.com/intent/tweet?url=<?php echo e($currenturl); ?>&text=<?php echo e($singleCourseDetail['course_title']); ?>&via=TY"><i class="fab fa-twitter fa-lg btn-close-white me-3"></i></a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>

      <div class="col-lg-6 col-md-12 order-1 order-lg-2">
        <img src="<?php echo e(asset('/storage/courseImages/'.$singleCourseDetail['course_image'])); ?>" alt="course-image" class="img-fluid course-picture" style="height: auto;">
      </div>
      <div class="row">

      </div>
    </div>
  </div>
</header>

<!-- course description -->
<section class="mt-5">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body p-4">
            <h5 class="card-title">Course description</h5>
            <?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="card-text-1"><?php echo e($singleCourseDetail['description']); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- course description end -->
<!-- course content-->
<section class="mt-3">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 d-flex flex-column">
        <div class="card card-2 mb-3 flex-grow-1">
          <div class="card-body">
            <h5 class="card-title border-bottom pb-3 pt-2">Course Content</h5>
            <?php ($slno = 0); ?>
            <?php $__currentLoopData = $courseContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($slno = $slno + 1); ?>
            <h6 class="card-subtitle mt-3"> Session <?php echo e($slno); ?> - <?php echo e($courseContent['topic_title']); ?></h6>
            <ul class="list-group list-group-flush border-bottom pb-3 mt-3">
              <?php $__currentLoopData = $courseContent['contentsData']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="ms-3 border-0 pb-2" style="list-style:circle;" id="<?php echo e($content['topic_content_id']); ?>"><?php echo e($content['topic_title']); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <!-- course content end-->
        <!-- Who is this course is for -->
        <div class="col-lg-12">
          <div class="card mb-3">
            <div class="card-body p-4">
              <h5 class="card-title">Who is this course for?</h5>
              <p class="card-text-1"><?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($singleCourseDetail['course_details']); ?>

              </p>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <p class="card-text-1 mb-2"><?php echo e($singleCourseDetail['course_details_points']); ?> </p>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
      <!-- instructor profile -->
      <div class="col-lg-4 d-flex flex-column">
        <div class="card card-3 mb-3">
          <div class="row g-0 border-bottom think-bg think-br">
            <div class="col-sm-auto col-12">
              <?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <img src="<?php echo e(asset('/storage/images/'.$singleCourseDetail['profile_photo'])); ?>" class="img-fluid rounded-circle m-2 p-2 d-flex align-items-center" alt="..." style="width:94px; height:94px;">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-sm col-12">
              <div class="card-body ps-2">
                <h5 class="card-title pt-2">
                  <?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($singleCourseDetail['instructor_firstname']); ?> <?php echo e($singleCourseDetail['instructor_lastname']); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </h5>
                <p class="card-text-1">
                  <?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($singleCourseDetail['designation']); ?> at <?php echo e($singleCourseDetail['institute']); ?>

                </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <p class="card-text-1 p-3" style="line-height: 32px;">
                <?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($singleCourseDetail['instructorDescription']); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </p>
            </div>

            <div class="row d-flex justify-content-center mb-4">
              <div class="col-auto">
                <a href="<?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php echo e($singleCourseDetail['instructorTwitter']); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" target="_blank">
                  <img class="me-2" src="/storage/icons/twitter__icon.svg" alt="error">
                </a>
              </div>
              <div class="col-auto">
                <a href="<?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($singleCourseDetail['instructorLinkedin']); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" target="_blank">
                  <img class="me-2" src="/storage/icons/linkedin__icon.svg" alt="error">
                </a>
              </div>
              <div class="col-auto">
                <a href="<?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($singleCourseDetail['instructorYoutube']); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" target="_blank">
                  <img class="me-2" src="/storage/icons/youtube__icon.svg" alt="error">
                </a>
              </div>
            </div>

          </div>

        </div>
        <!-- instructor profile end -->
        <!-- live cohorts -->
        <div class="card card-4 mb-3 mt-3 flex-grow-1 think-bg">
          <div class="card-body p-4">
            <h5 class="card-title mb-4">Upcoming Live Cohorts</h5>


            <?php if(count($batchDetails)): ?>
            <?php $__currentLoopData = $batchDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row g-0 border-bottom">
              <div class="col-auto">
              <?php $__currentLoopData = $singleCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset('/storage/courseImages/'.$singleCourseDetail['course_image'])); ?>" class="img-fluid mx-auto d-block py-2" alt="error" style="width:65px; height:74px;">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="col">
                <div class="card-body">
                  <h5 class="card-title">
                    <a style="text-decoration:none;color:#2C3443;"><?php echo e($batch['batchname']); ?></a>
                  </h5>
                  <p class="card-text course-time"><?php echo e($batch['batch_start_date']); ?>, <?php echo e($batch['batch_start_time']); ?> <?php echo e($batch['batch_time_zone']); ?> - 
                  <?php echo e($batch['batch_end_time']); ?> <?php echo e($batch['batch_time_zone']); ?>

                   </p>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <h6>No upcoming live cohorts!</h6>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
</section>
<!-- live cohorts end -->
<!-- student reviews -->
<section>
  <div class="container">
    <div class="row mb-4">
      <div class="col-lg-12">
        <div class="card card-5 mb-2">
          <div class="card-body p-4">
            <h5 class="card-title">Student Reviews</h5>
            <div class="row">
              <?php if(!empty($singleCourseFeedbacks)): ?>
              <?php $__currentLoopData = $singleCourseFeedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCourseFeedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-8 col-md-12 col-sm-12 col-12 d-flex justify-content-center">
                <img src="<?php echo e(asset('/storage/images/'.$singleCourseFeedback['studentProfilePhoto'])); ?>" class="img-fluid rounded-circle mt-3" alt="..." style="width:54px; height:54px;">
                <div class="card-body">
                  <h5 class="card-title text-left">
                    <?php echo e($singleCourseFeedback['studentFullname']); ?>

                  </h5>
                  <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <?php for($i = 1; $i<=5; $i++): ?> <?php if($i <=$singleCourseFeedback['rating']): ?> <i class="fas fa-star rateCourse"></i>
                        <?php else: ?>
                        <i class="far fa-star rateCourse"></i>
                        <?php endif; ?>
                        <?php endfor; ?>
                        <?php echo e($singleCourseFeedback['created_at']); ?>

                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                  <p class="card-text-1 p-2 review border-bottom">
                    <?php echo e($singleCourseFeedback['comment']); ?>

                  </p>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <?php if (isset($component)) { $__componentOriginal371e6c15748920a5baa19f8a6ff5d0168dc42d27 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Nodatafound::class, ['message' => 'No reviews yet.!','notype' => '']); ?>
<?php $component->withName('nodatafound'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal371e6c15748920a5baa19f8a6ff5d0168dc42d27)): ?>
<?php $component = $__componentOriginal371e6c15748920a5baa19f8a6ff5d0168dc42d27; ?>
<?php unset($__componentOriginal371e6c15748920a5baa19f8a6ff5d0168dc42d27); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- student reviews end-->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/assets/singlecourse.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('child-scripts'); ?>
<script>
  if(document.getElementById('enrollButton')){
    document.getElementById('enrollButton').addEventListener('click', (e) => {
      e.preventDefault();
      let path = "<?php echo e(route('student.course.enroll')); ?>";
      fetch(path, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          "X-CSRF-Token": document.querySelector('input[name=_token]').value
        },

      }).then((response) => response.json()).then((data) => {
        if (data.status == 'success') {
          let courseId = document.getElementById('course_id').value;
          window.location.href = "/register-course?id=" + courseId;

        } else {
          let loginModal = new bootstrap.Modal(
            document.getElementById("loginModal"), {});
          loginModal.show();
        }
      });
    });
  }

  let finalRating = 0;

  let stars = document.getElementsByClassName('rating-star');
  for (var index = 0; index < stars.length; index++) {
    stars[index].addEventListener('click', function(event) {
      let starRating = parseInt(this.getAttribute('star-rating'));

      for (var i = 0; i < starRating; i++) {
        stars[i].classList.add("active-stars");
      }
      for (var i = starRating; i < index; i++) {
        console.log(i);
        stars[i].classList.remove("active-stars");
      }
      finalRating = starRating;
    });
  }


  function closeModal(modalId) {
    const truck_modal = document.querySelector('#' + modalId);
    const modal = bootstrap.Modal.getInstance(truck_modal);
    modal.hide();
  }
  window.onload = function(event) {
    var currentURL = window.location.href;
    var els=document.getElementsByClassName("redirect_page");
    for (var i=0;i<els.length;i++) {
      els[i].value = currentURL;
    }
    var toastLiveExample = document.getElementById('liveToast');
    if(toastLiveExample) {
      var toast = new bootstrap.Toast(toastLiveExample);
      toast.show();
    }
    let title = document.getElementById('twittertitle').value;
    let description = document.getElementById('twitterdescription').value;
    let image = document.getElementById('twitterimage').value;
    let creator = document.getElementById('twittercreator').value;
    if(title){
      //document.getElementById('twitter_title').setAttribute("content", title);
    }
    if(description){
      //document.getElementById('twitter_description').setAttribute("content", description);
    }
    if(image){
      //document.getElementById('twitter_image').setAttribute("content", image);
    }
    if(creator){
      //document.getElementById('twitter_creator').setAttribute("content", creator);
    }
  }
</script>
<script type="text/javascript" src="<?php echo e(asset('/assets/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Student/showCourse.blade.php ENDPATH**/ ?>
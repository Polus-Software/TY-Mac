<tr>
<td class="header">
<a href="<?php echo e(url('/')); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="https://laravel.com/img/notification-logo.png" class="logo" alt="Laravel Logo">
<?php else: ?>
<img src="<?php echo e(url('/')); ?>/storage/logo/ty_mac__vector.svg" class="logo" alt="My logo" style="width:85px">
<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>
<!-- timezone -->
<?php
use App\Models\CustomTimezone;

$date = new DateTime("now");
$timezones = CustomTimezone::Orderby('offset')->get();
?>
<?php $__currentLoopData = $timezones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timezone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <option value="<?php echo e($timezone->name); ?>">(<?php echo e($timezone->diff_from_gtm); ?>) <?php echo e($timezone->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Course/admin/timezones.blade.php ENDPATH**/ ?>
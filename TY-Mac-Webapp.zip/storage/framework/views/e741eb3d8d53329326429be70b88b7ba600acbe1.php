<div class="think-nodata-box px-4 py-5 my-5 text-center mh-100">
    <?php if($notype === 'video'): ?>
    <img class="mb-3" src="/storage/icons/no_video.svg" alt="<?php echo e($message); ?>">
    <?php else: ?>
    <img class="mb-3" src="/storage/icons/no_data_available.svg" alt="<?php echo e($message); ?>">
    <?php endif; ?>
    <h4 class="fw-bold"><?php echo e($message); ?></h4>
</div><?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/components/nodatafound.blade.php ENDPATH**/ ?>
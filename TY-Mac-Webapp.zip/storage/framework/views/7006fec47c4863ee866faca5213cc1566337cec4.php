<footer class="footer">
<div class="container">
      <div class="row text-white justify-content-center mt-3 pb-3">

        <div class="col-12 col-sm-6 col-lg-6 mx-auto ms-0">
          <h5 class="text-capitalize fw-bold">About Us</h5>
          <hr class="bg-white d-inline-block mb-4" style="width: 60px; height: 2px;">
          <p class="lh-lg" style="font-weight:400;">
          Our teaching format makes it easy and fun to learn any new skill! Tag along with us on this personalized learning experience.
          </p>          
        </div>
        <div class="col-12 col-sm-3 col-lg-3 mx-auto">
          <h5 class="text-capitalize fw-bold">Quick links</h5>
          <hr class="bg-white d-inline-block mb-4" style="width: 60px; height: 2px;">
          <ul class="list-inline campany-list">
          <li><a href="#">Privacy policy</a></li>
            <li class="ms-3"><a href="#">Terms & conditions</a></li>
          </ul>
        </div>
        <div class="col-12 col-sm-3 col-lg-3 mx-auto">
          <h5 class="text-capitalize fw-bold">Connect us</h5>
          <hr class="bg-white d-inline-block mb-4" style="width: 60px; height: 2px;">
          <div class="col-12 footer-sm">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
          </div>
        </div>
      </div>
    </div>

    <!-- START THE COPYRIGHT INFO  -->
    <div class="footer-bottom pt-3 pb-3">
      <div class="container">
        <div class="row text-center text-white">
          <div class="col-12">
            <div class="footer-bottom__copyright">
              &COPY; Copyright 
              <?php echo date('Y'); ?>
              <a href="#">Thinklit</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
<!-- signup modal -->
<?php echo $__env->make('modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- signup modal ends -->
<?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/footer.blade.php ENDPATH**/ ?>
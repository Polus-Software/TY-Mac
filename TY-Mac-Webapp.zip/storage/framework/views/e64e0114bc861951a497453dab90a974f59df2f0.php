<!-- sidebar -->

<div class="d-flex flex-column flex-shrink-0 bg-light">
  <ul class="nav nav-pills flex-column mb-auto mt-5 llp-sidebar">
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
      <i class="fas fa-home"></i>
        Dashboard</a>
    </li>
    <li class="nav-item">
      <a class="nav-link link-dark text-uppercase pe-none" href="<?php echo e(route('manage-course-categories')); ?>">Management</a>
    </li>
    
    <?php if($userType == 'admin' || $userType == 'content_creator'): ?>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'attendance.tracker.view' ? 'active' : ''); ?>" href="<?php echo e(route('attendance.tracker.view')); ?>">
      <i class="fas fa-graduation-cap"></i>
        Attendance Tracker</a>
    </li>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'admin.viewall' ? 'active' : ''); ?>" href="<?php echo e(route('admin.viewall')); ?>">
      <i class="fas fa-users"></i>
        Students</a>
    </li>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'manage-instructors' ? 'active' : ''); ?>" href="<?php echo e(route('manage-instructors')); ?>">
      <i class="fas fa-user-friends"></i>
        Instructors</a>
    </li>
    <?php if($userType == 'admin'): ?>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'manage-creators' ? 'active' : ''); ?>" href="<?php echo e(route('manage-creators')); ?>">
      <i class="fas fa-users-cog"></i>
        Content Creators</a>
    </li>
    
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'manage-admin' ? 'active' : ''); ?>" href="<?php echo e(route('manage-admin')); ?>">
      <i class="fas fa-users-cog"></i>
        Admin Users</a>
    </li>
    <?php endif; ?>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'manage-course-categories' ? 'active' : ''); ?>" href="<?php echo e(route('manage-course-categories')); ?>">
      <i class="fas fa-clipboard-list"></i>
        Course Categories</a>
    </li>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'manage-courses' ? 'active' : ''); ?>" href="<?php echo e(route('manage-courses')); ?>">
      <i class="fas fa-book-reader"></i>
        Courses</a>
    </li>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'schedule-session' ? 'active' : ''); ?>" href="<?php echo e(route('schedule-session')); ?>">
      <i class="fas fa-book-reader"></i>
        Schedule Live Session</a>
    </li>
    <?php if($userType == 'admin'): ?>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'admin-settings' ? 'active' : ''); ?>" href="<?php echo e(route('admin-settings')); ?>">
      <i class="fas fa-cogs"></i>
        App Settings</a>
    </li>
    <?php endif; ?>
	<li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'admin.manager_reviews' ? 'active' : ''); ?> <?php echo e(Route::currentRouteName() == 'admin.manager_reviews_filter' ? 'active' : ''); ?>" href="<?php echo e(route('admin.manager_reviews')); ?>">
      <i class="fas fa-cogs"></i>
        Manage Reviews</a>
    </li>
    <?php elseif($userType == 'instructor'): ?>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'sessions-view' ? 'active' : ''); ?>" href="<?php echo e(route('sessions-view')); ?>">
        View Scheduled Sessions</a>
    </li>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'change.password.get' ? 'active' : ''); ?>" href="<?php echo e(route('change.password.get')); ?>">Change Password</a>
    </li>

    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'assigned-courses' ? 'active' : ''); ?>" href="<?php echo e(route('assigned-courses')); ?>">Assigned Courses</a>
    </li>
    <?php else: ?>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'change.password.get' ? 'active' : ''); ?>" href="<?php echo e(route('change.password.get')); ?>">
        <svg class="bi me-2" width="16" height="16">
          <use xlink:href="#table" />
        </svg>
        Change Password</a>
    </li>
    <li class="nav-item">
      <a class="nav-link link-dark <?php echo e(Route::currentRouteName() == 'student.courses.get' ? 'active' : ''); ?>" href="<?php echo e(route('student.courses.get')); ?>">
      <i class="fas fa-book-reader"></i>
        Courses</a>
    </li>
    <?php endif; ?>

  </ul>
</div>
<!-- sidebar ends -->


<script>

  let navLink = document.getElementsByClassName('nav-link');
  let navLinkLength = navLink.length;

  for(index = 0; index < navLinkLength; index++) {
    navLink[index].addEventListener('click', function(e) {
        // this.classList.add('active');
    });
  }
</script><?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Layouts/admin/sidebar.blade.php ENDPATH**/ ?>
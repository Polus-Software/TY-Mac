<?php $__env->startComponent('mail::message'); ?>

<h1>Hello <?php echo e($details['studentName']); ?></h1>

You have got a reply to your message from your Instructor <?php echo e($details['instructorName']); ?> 
for the course <?php echo e($details['courseTitle']); ?>  on Thinklit.

To view the message, please log in to your account on ThinkLit.com

Regards,<br>
The ThinkLit Team


<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Emails/MailAfterReplay.blade.php ENDPATH**/ ?>
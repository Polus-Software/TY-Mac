<?php $__env->startComponent('mail::message'); ?>

Hello <?php echo e($data['adminFirstName']); ?> <?php echo e($data['adminLastName']); ?>,

You have got a new student registration on ThinkLit.

Details:<br>

Student Name : <?php echo e($data['firstname']); ?> <?php echo e($data['lastname']); ?><br>
Email Id : <?php echo e($data['email']); ?><br>

To view registered students, please log in to your account on ThinkLit.com


Regards,<br>
Thinklit Team

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Emails/AdminMailAfterSignUp.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('Layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- container -->
<div class="container-fluid llp-container">
  <div class="row">
    <div class="left_sidebar">
      <?php echo $__env->make('Layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-8 right_card_block">
      <!-- main -->
      <main>
        <?php if($userType == "admin" || $userType == "content_creator"): ?>
        <div class="row mt-4">
          <div class="col-12 col-lg-3 col-md-3 col-sm-6">
            <div class="card llp-countbox mb-3">
              <div class="card-body text-center">
                <h1 class="card-title"><?php echo e($registered_course_count); ?></h5>
                  <p class="card-text">Course registered</p>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-3 col-md-3 col-sm-6">
            <div class="card llp-countbox mb-3">
              <div class="card-body">
                <h1 class="card-title text-center"><?php echo e($students_registered); ?></h5>
                  <p class="card-text text-center">Total students joined</p>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-3 col-md-3 col-sm-6">
            <div class="card llp-countbox mb-3">
              <div class="card-body text-center">
                <h1 class="card-title"><?php echo e($instructor_count); ?></h5>
                  <p class="card-text">Total instructor</p>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-3 col-md-3 col-sm-6">
            <div class="card llp-countbox mb-3">
              <div class="card-body text-center">
                <h1 class="card-title"><?php echo e($total_live_hours); ?></h5>
                  <p class="card-text">Total Live Hours</p>
              </div>
            </div>
          </div>
        </div>
        
        <div class="row mt-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
            <h3 class="titles">Upcoming cohorts</h3>
          </div>
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center mb-3">
              <table class="table llp-table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Instructor</th>
                    <th scope="col">Participants</th>
                    <th scope="col">Date/Time</th>
                  </tr>
                </thead>
                <tbody>
                <?php ($slno = 0); ?>
                <?php if(!empty($upComingSessionDetails)): ?>
               <?php $__currentLoopData = $upComingSessionDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upComingSessionDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($slno = $slno + 1); ?>
                  <tr id="">
                    <td><?php echo e($slno); ?></td>
                    <td><?php echo e($upComingSessionDetail['session_title']); ?></td>
                    <td><?php echo e($upComingSessionDetail['instructor']); ?></td>
                    <td><?php echo e($upComingSessionDetail['enrolledCourses']); ?></td>
                    <td><?php echo e($upComingSessionDetail['date']); ?></td>
                    
                    
                    <td class="text-center"><i class="fas fa-ellipsis-v"></i></td>
                  </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <tr>
                      <td colspan="5"><h6 style="text-align:center;">No upcoming cohorts.</h6></td>
                  </tr>
                  <?php endif; ?>
                </tbody>
              </table>
              
			</div>
        </div>
        <div class="row mt-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
            <h3 class="titles">Recent cohorts</h3>
          </div>
		  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center mb-3">
          <table class="table llp-table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Instructor</th>
                <th scope="col">Participants</th>
                <th scope="col">Date/Time</th>
              </tr>
            </thead>
            <tbody>
              <?php ($slno = 0); ?>
              <?php if(!empty($recentSessionDetails)): ?>
            <?php $__currentLoopData = $recentSessionDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentSessionDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php ($slno = $slno + 1); ?>
              <tr>
                <td><?php echo e($slno); ?></td>
                <td><?php echo e($recentSessionDetail['session_title']); ?></td>
                <td><?php echo e($recentSessionDetail['instructor']); ?></td>
                <td><?php echo e($recentSessionDetail['enrolledCourses']); ?></td>
                <td><?php echo e($recentSessionDetail['date']); ?></td>
              </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php else: ?>
                 <tr>
                     <td colspan="5"><h6 style="text-align:center;">No recent cohorts.</h6></td>
                 </tr>
                 <?php endif; ?>
            </tbody>
          </table>
		  </div>
        </div>
        <?php endif; ?>
      </main>
      <!-- main ends -->

    </div>
	<div class="col-md-1"></div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Auth/Dashboard.blade.php ENDPATH**/ ?>
<?php $__env->startComponent('mail::message'); ?>

<h1>Hi <?php echo e($details['instructorName']); ?>,</h1>

Your live session <?php echo e($details['sessionTitle']); ?> is scheduled for <?php echo e($details['startDate']); ?>, <?php echo e($details['startTime']); ?>



Regards,<br>
The ThinkLit Team

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Emails/InstructorMailAfterLiveSessionScheduled.blade.php ENDPATH**/ ?>
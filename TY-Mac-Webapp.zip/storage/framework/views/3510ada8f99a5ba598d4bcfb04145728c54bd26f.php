
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('Layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- container -->
<div class="container-fluid llp-container">
  <div class="row">
  <div class="left_sidebar">
      <!-- include sidebar here -->
      <?php echo $__env->make('Course.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-8 right_card_block">
      <!-- main -->
      <main>
      <div class="py-4"><h5 class="titles">Course Title: <?php echo e($course_title); ?></h5></div>
      <div class="py-4">
          <ul class="nav nav-tabs llp-tabs">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="<?php echo e(route('view-subtopics', ['course_id' => $course_id])); ?>" style="text-decoration:none; color:inherit;">Topics List</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('create-subtopic', ['course_id' => $course_id])); ?>" style="text-decoration:none; color:inherit;">New Topic</a>
  </li>
</ul>
        </div>

        <div class="row">
         
          <div class="col-12 mb-3">
            <div class="card">
              <h5 class="card-title ms-3 mt-3 pb-2 border-bottom">
             <strong>Topics</strong>
              </h5>
              <div class="card-body">
              <?php ($slno = 0); ?>
                <?php $__currentLoopData = $courseContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($slno = $slno + 1); ?>
                <ul class="list-group list-group-flush border-bottom pb-3">
                
                <h6 class="card-subtitle mb-3 mt-3"> Session <?php echo e($slno); ?> - <?php echo e($courseContent['topic_title']); ?></h6>
                
                    <?php $__currentLoopData = $courseContent['contentsData']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="ms-4 border-0 pb-2" style="list-style:circle;" id="<?php echo e($content['topic_content_id']); ?>"><?php echo e($content['topic_title']); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-end mb-4">
                     
                      <a class="btn btn-sm btn-outline-dark me-2" href="<?php echo e(route('edit-subtopics', ['topic' => $courseContent['topic_id']])); ?>">Edit</a>
                      <a class="btn btn-sm btn-outline-dark" href="<?php echo e(route('delete-subtopics', ['topic' => $courseContent['topic_id']])); ?>">Delete</a>
                    </div>
                </ul>
                
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
             
              </div>
              
              </div>

              </div>
            </div>
            

          </div>
			<div class="col-1"></div>
        </div>
      </main>
      <!-- main ends -->
    </div>
  </div>
</div>
<!-- container ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Course/admin/view/view_subtopics.blade.php ENDPATH**/ ?>
<?php $__env->startComponent('mail::message'); ?>

<h1>Dear <?php echo e($data['studentName']); ?>,</h1>

Thank you for your interest in <?php echo e($data['courseTitle']); ?>. <br>
Live sessions for <?php echo e($data['courseTitle']); ?> have been scheduled from <?php echo e($data['startDate']); ?> to <?php echo e($data['endDate']); ?>.
We're excited to have you join our live session.<br>

Please join the session a couple of minutes earlier to make sure everything's working properly.
If you experience any technical issues, feel free to contact me via email.

I look forward to seeing you there.

Regards,<br>
<?php echo e($data['instructorName']); ?>


<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Emails/MailAfterLiveSessionScheduled.blade.php ENDPATH**/ ?>
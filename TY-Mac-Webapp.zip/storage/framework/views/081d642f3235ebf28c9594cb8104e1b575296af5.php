<?php echo e($slot); ?>

<?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('Layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php 
use App\Models\CustomTimezone;
?>
<!-- container -->
<div class="container-fluid llp-container">
  <div class="row">
  <div class="left_sidebar">
      <!-- include sidebar here -->
      <?php echo $__env->make('Course.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-8 right_card_block">
      <!-- main -->
      <main>
      
      <?php $__currentLoopData = $cohortbatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cohortbatch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('update_cohortbatches')); ?>" enctype="multipart/form-data" method="POST" class="row g-3 llp-form">
        <?php echo csrf_field(); ?>
        <input id="course_id" name="course_id" type="hidden" value="<?php echo e($cohortbatch->course_id); ?>">
        <input type="hidden" name="cohort_batch_id" value="<?php echo e($cohortbatch->id); ?>">
          <div class="py-4">
          <h3>Cohort Overview - </h3>
          <hr class="my-4">
        </div>
          <div class="col-12">
            <label for="title">Title</label>
            <input type="text" class="form-control" id="title" name="cohortbatch_title" value="<?php echo e($cohortbatch->title); ?>">
            <?php if($errors->has('cohortbatch_title')): ?>
              <span class="text-danger">The batch title is required</span>
            <?php endif; ?>
          </div>
          <div class="col-12">
            <label for="batchname">Batchname</label>
            <input type="text" class="form-control" id="batchname" name="batchname" value="<?php echo e($cohortbatch->batchname); ?>">
            <?php if($errors->has('batchname')): ?>
              <span class="text-danger">The batch name is required</span>
            <?php endif; ?>
          </div>
         
          <div class="col-md-6">
            <label for="level">Start date</label>
            <input type="text" class="form-control" id="title" name="cohortbatch_startdate" readonly value="<?php echo e($cohortbatch->start_date); ?>">
            <?php if($errors->has('cohortbatch_startdate')): ?>
              <span class="text-danger">The batch start date is required</span>
            <?php endif; ?>
          </div>
          <div class="col-md-6">
          <label for="level">End date</label>
            <input type="text" class="form-control" id="title" name="cohortbatch_enddate" readonly value="<?php echo e($cohortbatch->end_date); ?>">
            <?php if($errors->has('cohortbatch_enddate')): ?>
              <span class="text-danger">The batch end date is required</span>
            <?php endif; ?>
          </div>
          <label for="batch">Batch</label>
          <input type="hidden" name="cohortbatch_batchname" id="batch_name" value="Daily">
          <div class="col-12">
            <div class="form-check">
            <?php if($cohortbatch->occurrence == "Daily"): ?>
            <input class="form-check-input" type="radio" name="cohortbatchdaily" id="cohortbatchdaily" value="Daily" checked>
            <?php else: ?>
            <input class="form-check-input" type="radio" name="cohortbatchdaily" id="cohortbatchdaily" value="Daily">
            <?php endif; ?>
            <label class="form-check-label" for="cohortbatchdaily">
            Daily
            </label>
            </div>
          </div>

          <?php if($cohortbatch->occurrence != "Daily"): ?>
          <?php 
          $days = explode(',', $cohortbatch->occurrence);
          $sundayFlag = in_array('Sunday', $days) ? 'checked' : '';
          $mondayFlag = in_array('Monday', $days) ? 'checked' : '';
          $tuesdayFlag = in_array('Tuesday', $days) ? 'checked' : '';
          $wednesdayFlag = in_array('Wednesday', $days) ? 'checked' : '';
          $thursdayFlag = in_array('Thursday', $days) ? 'checked' : '';
          $fridayFlag = in_array('Friday', $days) ? 'checked' : '';
          $saturdayFlag = in_array('Saturday', $days) ? 'checked' : '';
          ?>
          <div class="col-12">
            <div class="form-check">
            <input class="form-check-input" type="radio" name="cohortbatchdaily" id="cohortbatchcustom" checked> 
            <label class="form-check-label" for="cohortbatchcustom">
            Custom
            </label>
            </div>
          </div>
          <div class="col-12" id="cohortbatchdaycontainer">
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Sunday" <?php echo e($sundayFlag); ?>>
              <label class="form-check-label" for="flexCheckDefault">
              Sunday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Monday" <?php echo e($mondayFlag); ?>>
              <label class="form-check-label" for="flexCheckDefault">
              Monday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Tuesday" <?php echo e($tuesdayFlag); ?>>
              <label class="form-check-label" for="flexCheckDefault">
              Tuesday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Wednesday"  <?php echo e($wednesdayFlag); ?>>
              <label class="form-check-label" for="flexCheckDefault">
              Wednesday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Thursday" <?php echo e($thursdayFlag); ?>>
              <label class="form-check-label" for="flexCheckDefault">
              Thursday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Friday" <?php echo e($fridayFlag); ?>>
              <label class="form-check-label" for="flexCheckDefault">
              Friday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Saturday"  <?php echo e($saturdayFlag); ?>>
              <label class="form-check-label" for="flexCheckDefault">
              Saturday
              </label>
            </div>
          </div>

          <?php else: ?>
          <div class="col-12">
            <div class="form-check">
            <input class="form-check-input" type="radio" name="cohortbatchdaily" id="cohortbatchcustom"> 
            <label class="form-check-label" for="cohortbatchcustom">
            Custom
            </label>
            </div>
          </div>
          <div class="col-12" id="cohortbatchdaycontainer" style="display:none;">
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Sunday">
              <label class="form-check-label" for="flexCheckDefault">
              Sunday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Monday">
              <label class="form-check-label" for="flexCheckDefault">
              Monday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Tuesday">
              <label class="form-check-label" for="flexCheckDefault">
              Tuesday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Wednesday">
              <label class="form-check-label" for="flexCheckDefault">
              Wednesday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Thursday">
              <label class="form-check-label" for="flexCheckDefault">
              Thursday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Friday">
              <label class="form-check-label" for="flexCheckDefault">
              Friday
              </label>
            </div>
          
            <div class="form-check">
              <input class="form-check-input cohortbatchday" type="checkbox" value="Saturday">
              <label class="form-check-label" for="flexCheckDefault">
              Saturday
              </label>
            </div>
          </div>
          <?php endif; ?>
          <div class="col-lg-3 col-md-3 col-sm-4 col-9">
            <label for="duration">Start time</label>
            <?php 
             

              $offset = CustomTimezone::where('name', $cohortbatch->time_zone) ->value('offset');
          
              $offsetHours = intval($offset[1] . $offset[2]);
              $offsetMinutes = intval($offset[4] . $offset[5]);
              
              if($offset[0] == "+") {
                  $sTime = strtotime($cohortbatch->start_time) + (60 * 60 * $offsetHours) + (60 * $offsetMinutes);
                  $eTime = strtotime($cohortbatch->end_time) + (60 * 60 * $offsetHours) + (60 * $offsetMinutes);
              } else {
                  $sTime = strtotime($cohortbatch->start_time) - (60 * 60 * $offsetHours) - (60 * $offsetMinutes);
                  $eTime = strtotime($cohortbatch->end_time) - (60 * 60 * $offsetHours) - (60 * $offsetMinutes);
              }

              $startTime = date("H:i:s", $sTime);
              $endTime = date("H:i:s", $eTime);

            ?>
            <input type="text" class="form-control" id="duration" name="cohortbatch_starttime" readonly value="<?php echo e($startTime); ?>">
            <?php if($errors->has('cohortbatch_starttime')): ?>
              <span class="text-danger">The batch start time is required</span>
            <?php endif; ?>
          </div>
          <div class="col-lg-1 col-md-1 col-sm-2 col-3">
            <select name="" id="" class="form-control mt-4">
              <option value="AM">AM</option>
              <option value="PM">PM</option>
            </select>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-4 col-9">
            <label for="duration">End time</label>
            <input type="text" class="form-control" id="duration" name="cohortbatch_endtime" readonly value="<?php echo e($endTime); ?>">
            <?php if($errors->has('cohortbatch_endtime')): ?>
              <span class="text-danger">The batch end time is required</span>
            <?php endif; ?>
          </div>
          <div class="col-lg-1 col-md-1 col-sm-2 col-3">
            <select name="" id="" class="form-control mt-4">
              <option value="AM">AM</option>
              <option value="PM">PM</option>
            </select>
          </div>
          <div class="col-md-4">
            <label for="duration">Timezone</label>
            <select id="cohortbatch_timezone" name="cohortbatch_timezone" class="form-control" checked value="<?php echo e($cohortbatch->time_zone); ?>">
    <!-- include timezones here -->
              <?php echo $__env->make('Course.admin.timezones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </select>
            <?php if($errors->has('cohortbatch_timezone')): ?>
              <span class="text-danger">The time zone is required</span>
            <?php endif; ?>
          </div>
          <div class="col-md-3">
            <label for="students_count">No. of students</label>
            <input type="text" class="form-control" id="students_count" name="students_count" value="<?php echo e($cohortbatch->students_count); ?>">
            <?php if($errors->has('students_count')): ?>
              <span class="text-danger">Number of students in the batch is required</span>
            <?php endif; ?>
          </div>
          <div class="col-12">
            <label for="description">Notification</label>
            
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check">
                <input type="checkbox" value="<?php echo e($notification->id); ?>" name="cohortbatch_notification_<?php echo e($notification->id); ?>" checked>
                <label for=""><?php echo e($notification->description); ?></label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </div>          
          <div class="d-grid gap-2 d-md-flex justify-content-md-end mb-5">
          <button class="btn btn-primary" id="update_course" type="submit" value="Update">Update</button>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
      </main>
    </div>
    <div class="col-1"></div>
  </div>
</div>
<!-- container ends -->

<link rel="stylesheet" href="<?php echo e(asset('/assets/dtsel.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('/assets/dtsel.js')); ?>"></script>
<script>
  let selectedTimeZone = document.getElementById('cohortbatch_timezone').getAttribute('value');
  document.getElementById('cohortbatch_timezone').value = selectedTimeZone;
  startdate = new dtsel.DTS('input[name="cohortbatch_startdate"]', {
    paddingX: 15, paddingY: 15
  });
  enddate = new dtsel.DTS('input[name="cohortbatch_enddate"]', {
    paddingX: 15, paddingY: 15
  });
  starttime = new dtsel.DTS('input[name="cohortbatch_starttime"]', {
    paddingX: 15, paddingY: 15,showTime: true, showDate: false
  });
  endtime = new dtsel.DTS('input[name="cohortbatch_endtime"]', {
    paddingX: 15, paddingY: 15,showTime: true, showDate: false
  });

  const cohortbatchdailyEl = document.querySelector('#cohortbatchdaily');
  const cohortbatchdayElList =  document.querySelectorAll('.cohortbatchday');
  const cohortbatchdaycontainer = document.querySelector('#cohortbatchdaycontainer');
  const cohortbatchcustom = document.querySelector('#cohortbatchcustom');
  cohortbatchdailyEl.addEventListener('change', (e)=>{
    cohortbatchdaycontainer.style.display = 'none';
    document.querySelector('#batch_name').value = e.currentTarget.value;
  });
  let customValue = [];
  const cohortbatchdayList = document.querySelectorAll('.cohortbatchday');
  cohortbatchcustom.addEventListener('change', ()=>{
    customValue = [];
    cohortbatchdaycontainer.style.display = 'block';
    
    cohortbatchdayList.forEach((el) => {
      if(el.checked) {
        customValue.push(el.value);
      }
    });
    document.querySelector('#batch_name').value = customValue;
  });
  cohortbatchdayList.forEach((el) => {
    el.addEventListener('change', (e) => {
      const currentItem = e.currentTarget;
        if(currentItem.checked) {
          customValue.push(currentItem.value);
        } else {
          if(customValue.indexOf(currentItem.value) != -1) {
            customValue.splice(customValue.indexOf(currentItem.value), 1);
          }

        }
        document.querySelector('#batch_name').value = customValue;
    });
  })

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\TY-Mac\resources\views/Course/admin/edit_cohortbatch.blade.php ENDPATH**/ ?>